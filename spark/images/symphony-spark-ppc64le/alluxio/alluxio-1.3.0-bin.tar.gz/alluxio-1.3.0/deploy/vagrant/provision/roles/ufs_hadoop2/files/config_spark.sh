#!/usr/bin/env bash

echo "export HADOOP_CONF_DIR=/hadoop/etc/hadoop" >> /spark/conf/spark-env.sh
