#!/usr/bin/env bash

echo 'alluxio.worker.block.heartbeat.timeout.ms=1000000' >> /alluxio/conf/alluxio-site.properties
