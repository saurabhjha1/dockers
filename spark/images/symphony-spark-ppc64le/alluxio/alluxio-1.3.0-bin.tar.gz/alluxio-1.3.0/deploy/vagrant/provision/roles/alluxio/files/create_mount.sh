#!/usr/bin/env bash

cd /alluxio
./bin/alluxio-mount.sh SudoMount
