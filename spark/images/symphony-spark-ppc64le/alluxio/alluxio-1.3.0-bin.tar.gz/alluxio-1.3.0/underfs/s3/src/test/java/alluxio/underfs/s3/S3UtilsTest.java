/*
 * The Alluxio Open Foundation licenses this work under the Apache License, version 2.0
 * (the "License"). You may not use this work except in compliance with the License, which is
 * available at www.apache.org/licenses/LICENSE-2.0
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied, as more fully set forth in the License.
 *
 * See the NOTICE file distributed with this work for information regarding copyright ownership.
 */

package alluxio.underfs.s3;

import org.jets3t.service.acl.AccessControlList;
import org.jets3t.service.acl.CanonicalGrantee;
import org.jets3t.service.acl.GroupGrantee;
import org.jets3t.service.acl.Permission;
import org.jets3t.service.model.StorageOwner;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link S3Utils} methods.
 */
public final class S3UtilsTest {

  private static final String NAME = "foo";
  private static final String ID = "123456789012";
  private static final String OTHER_ID = "987654321098";

  private CanonicalGrantee mUserGrantee;
  private AccessControlList mAcl;

  @Before
  public void before() throws Exception {
    // Setup owner.
    mUserGrantee = new CanonicalGrantee(ID);
    mUserGrantee.setDisplayName(NAME);

    // Setup the acl.
    mAcl = new AccessControlList();
    mAcl.setOwner(new StorageOwner(ID, NAME));
  }

  @Test
  public void translateUserReadPermission() {
    mAcl.grantPermission(mUserGrantee, Permission.PERMISSION_READ);
    Assert.assertEquals((short) 0500, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0000, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
    mAcl.grantPermission(mUserGrantee, Permission.PERMISSION_READ_ACP);
    Assert.assertEquals((short) 0500, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0000, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateUserWritePermission() {
    mAcl.grantPermission(mUserGrantee, Permission.PERMISSION_WRITE);
    Assert.assertEquals((short) 0200, S3Utils.translateBucketAcl(mAcl, ID));
    mAcl.grantPermission(mUserGrantee, Permission.PERMISSION_READ);
    Assert.assertEquals((short) 0700, S3Utils.translateBucketAcl(mAcl, ID));
  }

  @Test
  public void translateUserFullPermission() {
    mAcl.grantPermission(mUserGrantee, Permission.PERMISSION_FULL_CONTROL);
    Assert.assertEquals((short) 0700, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0000, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateEveryoneReadPermission() {
    GroupGrantee allUsersGrantee = GroupGrantee.ALL_USERS;
    mAcl.grantPermission(allUsersGrantee, Permission.PERMISSION_READ);
    Assert.assertEquals((short) 0500, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0500, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateEveryoneWritePermission() {
    GroupGrantee allUsersGrantee = GroupGrantee.ALL_USERS;
    mAcl.grantPermission(allUsersGrantee, Permission.PERMISSION_WRITE);
    Assert.assertEquals((short) 0200, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0200, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateEveryoneFullPermission() {
    GroupGrantee allUsersGrantee = GroupGrantee.ALL_USERS;
    mAcl.grantPermission(allUsersGrantee, Permission.PERMISSION_FULL_CONTROL);
    Assert.assertEquals((short) 0700, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0700, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateAuthenticatedUserReadPermission() {
    GroupGrantee authenticatedUsersGrantee = GroupGrantee.AUTHENTICATED_USERS;
    mAcl.grantPermission(authenticatedUsersGrantee, Permission.PERMISSION_READ);
    Assert.assertEquals((short) 0500, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0500, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateAuthenticatedUserWritePermission() {
    GroupGrantee authenticatedUsersGrantee = GroupGrantee.AUTHENTICATED_USERS;
    mAcl.grantPermission(authenticatedUsersGrantee, Permission.PERMISSION_WRITE);
    Assert.assertEquals((short) 0200, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0200, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }

  @Test
  public void translateAuthenticatedUserFullPermission() {
    GroupGrantee authenticatedUsersGrantee = GroupGrantee.AUTHENTICATED_USERS;
    mAcl.grantPermission(authenticatedUsersGrantee, Permission.PERMISSION_FULL_CONTROL);
    Assert.assertEquals((short) 0700, S3Utils.translateBucketAcl(mAcl, ID));
    Assert.assertEquals((short) 0700, S3Utils.translateBucketAcl(mAcl, OTHER_ID));
  }
}
