---
layout: global
title: Accessing Alluxio From Zeppelin
nickname: Apache Zeppelin
group: Frameworks
priority: 4
---

[Apache Zeppelin](http://zeppelin.incubator.apache.org/) is a web-based notebook that enables
interactive data analytics. Alluxio 1.0 has been
[integrated](https://github.com/apache/incubator-zeppelin/blob/master/docs/interpreter/alluxio.md)
with Zeppelin and detailed instructions can be found
[here](http://zeppelin.incubator.apache.org/docs/0.6.0-incubating-SNAPSHOT/interpreter/alluxio.html).
